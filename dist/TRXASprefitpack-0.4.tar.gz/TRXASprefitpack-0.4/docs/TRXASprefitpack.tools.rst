TRXASprefitpack.tools package
=============================

Submodules
----------

.. toctree::
   :maxdepth: 4

   TRXASprefitpack.tools.TRXASprefitpack_info
   TRXASprefitpack.tools.auto_scale
   TRXASprefitpack.tools.broadening
   TRXASprefitpack.tools.fit_static
   TRXASprefitpack.tools.fit_tscan

Module contents
---------------

.. automodule:: TRXASprefitpack.tools
   :members:
   :undoc-members:
   :show-inheritance:
