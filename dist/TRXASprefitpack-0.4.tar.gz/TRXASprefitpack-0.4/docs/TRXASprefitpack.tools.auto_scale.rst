TRXASprefitpack.tools.auto\_scale module
========================================

.. automodule:: TRXASprefitpack.tools.auto_scale
   :members:
   :undoc-members:
   :show-inheritance:
