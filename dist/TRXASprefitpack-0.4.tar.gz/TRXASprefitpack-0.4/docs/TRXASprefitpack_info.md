# TRXASprefitpack_info

Access the document of TRXASprefitpack

Type ``TRXASprefitpack_info func_name`` to get a description of func_name

