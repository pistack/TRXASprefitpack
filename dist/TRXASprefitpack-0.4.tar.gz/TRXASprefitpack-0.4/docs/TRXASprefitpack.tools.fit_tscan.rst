TRXASprefitpack.tools.fit\_tscan module
=======================================

.. automodule:: TRXASprefitpack.tools.fit_tscan
   :members:
   :undoc-members:
   :show-inheritance:
