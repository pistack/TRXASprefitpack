'''
doc:
Submodule for the TRXASprefitpack documentation

:copyright: 2021 by pistack (Junho Lee).
:license: LGPL3.
'''

from .info import __info__
