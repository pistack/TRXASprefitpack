TRXASprefitpack package
=======================

Utilites
--------

.. toctree::

   auto_scale
   broadening
   fit_static
   fit_tscan
   TRXASprefitpack_info
   

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   TRXASprefitpack.data_process
   TRXASprefitpack.doc
   TRXASprefitpack.mathfun
   TRXASprefitpack.thy
   TRXASprefitpack.tools

Module contents
---------------

.. automodule:: TRXASprefitpack
   :members:
   :undoc-members:
   :show-inheritance:
