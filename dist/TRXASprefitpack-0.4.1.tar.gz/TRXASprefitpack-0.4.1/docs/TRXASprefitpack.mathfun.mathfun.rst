TRXASprefitpack.mathfun.mathfun module
======================================

.. automodule:: TRXASprefitpack.mathfun.mathfun
   :members:
   :undoc-members:
   :show-inheritance:
