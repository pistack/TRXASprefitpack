TRXASprefitpack.tools.fit\_static module
========================================

.. automodule:: TRXASprefitpack.tools.fit_static
   :members:
   :undoc-members:
   :show-inheritance:
