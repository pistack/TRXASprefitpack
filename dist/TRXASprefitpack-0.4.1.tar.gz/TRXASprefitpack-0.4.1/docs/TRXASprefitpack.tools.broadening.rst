TRXASprefitpack.tools.broadening module
=======================================

.. automodule:: TRXASprefitpack.tools.broadening
   :members:
   :undoc-members:
   :show-inheritance:
